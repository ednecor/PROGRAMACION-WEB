<?php
include "final.php";

$nombre = $_POST["nombre"];

$insertar="INSERT INTO rh (nombre, estado) values ('$nombre','1')";
$inse=mysqli_query($conexion, $insertar);

echo '<script>
    alert("Registro exitoso");
    window.history.go(-1);
    </script>';


mysqli_close($conexion);


?>