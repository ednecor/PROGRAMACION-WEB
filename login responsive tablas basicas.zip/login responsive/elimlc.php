<?php
include "final.php";

$codex = $_POST["idcategoria"];

$eliminar="SELECT * FROM categoria";
$elimi=mysqli_query($conexion, $eliminar);
$eli=mysqli_num_rows($elimi);

if($eli>0){
    $eliminr="UPDATE categoria set estado='0' where idcategoria='$codex'";
    $trg=mysqli_query($conexion, $eliminr);

    echo '<script>
    alert("Registro exitoso");
    window.history.go(-1);
    </script>';

           } else{

    echo '<script>
    alert("Codigo no encontrado");
    window.history.go(-1);
    </script>';
         }


mysqli_close($conexion);


?>