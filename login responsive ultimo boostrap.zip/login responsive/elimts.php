<?php
include "final.php";

$codex = $_POST["idtiposangre"];

$eliminar="SELECT * FROM tiposangre";
$elimi=mysqli_query($conexion, $eliminar);
$eli=mysqli_num_rows($elimi);

if($eli>0){
    $eliminr="UPDATE tiposangre set estado='0' where idtiposangre='$codex'";
    $trg=mysqli_query($conexion, $eliminr);

    echo '<script>
    alert("Registro exitoso");
    window.history.go(-1);
    </script>';

           } else{

    echo '<script>
    alert("Codigo no encontrado");
    window.history.go(-1);
    </script>';
         }


mysqli_close($conexion);


?>