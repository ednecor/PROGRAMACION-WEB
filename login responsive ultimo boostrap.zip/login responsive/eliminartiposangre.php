<?php
include "final.php";
error_reporting(0);
session_start();

$varse = $_SESSION['numerodocumento'];
$varsesion = $_SESSION ['usuario'];
$var=$_SESSION['tiempo'];



if($varsesion==null || $varsesion = ''){
  echo '<script>
  alert("Por favor, inicie sesión para ingresar");
  window.location.href = "login.php";
    </script>';
    die();
}

$consu="SELECT * from usuario where numerodocumento=$varse";
$r=mysqli_query($conexion, $consu);
$f=mysqli_fetch_array($r);

$consulta="SELECT * from empresa";
$resultado=mysqli_query($conexion, $consulta);
$nombre=mysqli_fetch_array($resultado);


$rol=$_SESSION['rol'];
$con="select * from permiso where idpermiso in (select idpermiso from permisorol where idrol='$rol' and estado='1') order by cast(idpermiso as decimal);";
$resul=mysqli_query($conexion,$con);

$cons="SELECT rol.nombre from rol where idrol=$rol";
$res=mysqli_query($conexion, $cons);
$c=mysqli_fetch_array($res);
                     
$ctido="SELECT * from tiposangre where estado='1'";
$ctd=mysqli_query($conexion,$ctido);

$fgt="SELECT * from tiposangre where estado='0'";
$dtr=mysqli_query($conexion,$fgt);

 if (time() - $var >10000) {  
  echo '<script>
    alert("Ha estado inactivo");
    window.location.href="login.php";
      </script>';
    session_destroy();

  die();  
}
$_SESSION['tiempo']=time(); 
?>

<link href="es.css" rel="stylesheet" type="text/css">

<header>
    
  <form action="menuu.php" method="POST">
      <button class="s"><h2>Volver al inicio</h2></button>
  </form>

</header>

<div class="contain">

    <div class="wrapper">
      <div class="contacts">
        <h3><?php echo $nombre['nombre'] ?></h3>
  
        <ul>
          <li> <?php echo $c['nombre']?></li>
          <li> <?php echo $f['nombre'] . " ". $f['apellido']?> </li>
          <li> <?php echo $f['numerodocumento'] ?> </li>
        </ul>
      </div>
  
      <div class="form">
        <h3>Eliminar tipo de sangre</h3>
        <form action="elimts.php" method="POST">
          <p>
            <label for="">Codigo del tipo de sangre</label>
            <input type="text" name="idtiposangre" placeholder="Digite el codigo">
          </p>
          <p>
          
          </p>
        
          <p class="full-width">
            <label for="">Lista de tipos de sangre activo</label>
            <br>
            <?php
            echo "<table border='1'>
              <tr>
                <td>Codigo</td>
                <td>Nombre</td>
              
             </tr>";

              while($fila = mysqli_fetch_array($ctd)){

               echo "<tr>";
               echo "<td>" .$fila['idtiposangre']. "</td>";
               echo "<td>"  .$fila['nombre']. "</td>";
            
               echo "</tr>";

              }?>
            </table>

            <br><br>
            <label for="">Lista de tipos de sangre inactivos</label>
            <br>
            <?php
            echo "<table border='1'>
              <tr>
                <td>Codigo</td>
                <td>Nombre</td>
              
             </tr>";

              while($fils = mysqli_fetch_array($dtr)){

               echo "<tr>";
               echo "<td>" .$fils['idtiposangre']. "</td>";
               echo "<td>"  .$fils['nombre']. "</td>";
            
               echo "</tr>";

              }?>
            </table>
            
          </p>
          <p class="full-width">
          <br><br>
            <button>Eliminar</button>
          </p>
        </form>
      </div>
    </div>
  </div>
  
  <?php 

  mysqli_free_result($consu);
  mysqli_free_result($consulta);
  mysqli_free_result($cons);
  mysqli_free_result($ctido);
  mysqli_free_result($fgt);
  mysqli_close($conexion);
  
  ?>