<?php
include "final.php";
error_reporting(0);
session_start();

$varse = $_SESSION['numerodocumento'];
$varsesion = $_SESSION ['usuario'];
$var=$_SESSION['tiempo'];



if($varsesion==null || $varsesion = ''){
  echo '<script>
  alert("Por favor, inicie sesión para ingresar");
  window.location.href = "login.php";
    </script>';
    die();
}

$consu="SELECT * from usuario where numerodocumento=$varse";
$r=mysqli_query($conexion, $consu);
$f=mysqli_fetch_array($r);

$consulta="SELECT * from empresa";
$resultado=mysqli_query($conexion, $consulta);
$nombre=mysqli_fetch_array($resultado);


$rol=$_SESSION['rol'];
$con="select * from permiso where idpermiso in (select idpermiso from permisorol where idrol='$rol' and estado='1') order by cast(idpermiso as decimal);";
$resul=mysqli_query($conexion,$con);

$cons="SELECT rol.nombre from rol where idrol=$rol";
$res=mysqli_query($conexion, $cons);
$c=mysqli_fetch_array($res);
                     


 if (time() - $var >10000) {  
  echo '<script>
    alert("Ha estado inactivo");
    window.location.href="login.php";
      </script>';
    session_destroy();

  die();  
}
$_SESSION['tiempo']=time(); 
?>


<html>
<link href="es.css" rel="stylesheet" type="text/css">

<header>
    
    <form action="menuu.php" method="POST">
        <button class="s"><h2>Volver al inicio</h2></button>
    </form>

</header>

<div class="contain">

    <div class="wrapper">
       
                <div class="contacts">
        <h3><?php echo $nombre['nombre'] ?></h3>
  
        <ul>
        
          <li> <?php echo $c['nombre']?></li>
          <li> <?php echo $f['nombre'] . " ". $f['apellido']?> </li>
          <li> <?php echo $f['numerodocumento'] ?> </li>
        </ul>

      </div>
      
      <form action="actualizar.php" method="post" >
        <h2>Actualizar información personal</h2>
        <br><br>
        <form action="">
          <p>
            <label for="">Nombre</label>
            <input type="text" name="nombre" placeholder= "<?php echo $f['nombre']?>" >
            <br>
            <br>
            <label for="">Email</label>
            <input type="text" name="email" placeholder="<?php echo $f['email']?>">
            
          </p>
          <p>
            <label for="">Apellido</label>
            <input type="text" name="apellido" placeholder="<?php echo $f['apellido']?>">
            <br>
            <br>
            <label for="">Tipo de sangre</label>
            <input type="text " name="tiposangre" placeholder="<?php if(is_null($f['tiposangre']) || empty($f['tiposangre'])): {echo "vacio";}else:{echo $f['tiposangre'];} endif?>">
            <br>
         
            
          </p>
         
         <p>
            <br>
        
            <label for="">Telefono</label>
            <input type="text" name="telefono" placeholder="<?php echo $f['telefono']?>">
           
         
         
          </p>
          <p>
            <br>
            <label for="">Celular</label>
            <input type="text" name="celular" placeholder="<?php if(is_null($f['celular']) || empty($f['celular'])): {echo "vacio";}else:{echo $f['celular'];} endif?>">
           
          </p>
         

          <p>
            <br>
           
            <label for="">Dirección</label>
            <input type="text" name="direccion" placeholder="<?php if(is_null($f['direccion']) || empty($f['direccion'])): {echo "vacio";}else:{echo $f['direccion'];} endif?>">
            
          </p>
      
         
          <p>
            <br>
            <br>
            <button>Actualizar</button>
          </p>
        </form>
      </div>
    </div>
  </div>
  </html>

  <?php 

  mysqli_free_result($consu);
  mysqli_free_result($consulta);
  mysqli_free_result($cons);
  mysqli_close($conexion);
  
  ?>
  