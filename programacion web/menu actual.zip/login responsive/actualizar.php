<?php
include "final.php";
error_reporting(0);
session_start();

$varse = $_SESSION['numerodocumento'];
$varsesion = $_SESSION ['usuario'];
$var=$_SESSION['tiempo'];



if($varsesion==null || $varsesion = ''){
  echo '<script>
  alert("Por favor, inicie sesión para ingresar");
  window.location.href = "login.php";
    </script>';
    die();
}


$consulta="SELECT * from empresa";
$resultado=mysqli_query($conexion, $consulta);
$nombre=mysqli_fetch_array($resultado);


$rol=$_SESSION['rol'];
$con="select * from permiso where idpermiso in (select idpermiso from permisorol where idrol='$rol' and estado='1') order by cast(idpermiso as decimal);";
$resul=mysqli_query($conexion,$con);



 if (time() - $var >10000) {  
  echo '<script>
    alert("Ha estado inactivo");
    window.location.href="login.php";
      </script>';
    session_destroy();

  die();  
}
$_SESSION['tiempo']=time(); 


$nombre=$_POST['nombre'];
$apellido=$_POST['apellido'];
$telefono=$_POST['telefono'];
$celular=$_POST['celular'];
$email=$_POST['email'];
$tiposangre=$_POST['tiposangre'];
$direccion=$_POST['direccion'];

$cb="SELECT * from usuario where numerodocumento=$varse";
$resultadoo=mysqli_query($conexion, $cb);
$gh=mysqli_fetch_array($resultadoo);

if(empty($tiposangre)) { $tiposangre=$gh['tiposangre']; } 
if(empty($nombre)) {$nombre=$gh['nombre']; } 
if(empty($apellido)) {$apellido=$gh['apellido']; } 
if(empty($telefono)) {$telefono=$gh['telefono']; } 
if(empty($celular)) {$celular=$gh['celular']; } 
if(empty($direccion)) {$direccion=$gh['direccion']; } 
if(empty($email)) {$email=$gh['email']; } 

$filas=mysqli_num_rows($resultadoo);
if($filas > 0){
$bb="update usuario set nombre='$nombre', apellido='$apellido', telefono= '$telefono', email='$email', celular='$celular', direccion='$direccion', tiposangre='$tiposangre' where numerodocumento=$varse";
$resul=mysqli_query($conexion, $bb);

echo '<script>
alert("actualizacion exitosa");
</script>';

header("location:menuu.php");

}

mysqli_free_result($consulta);
mysqli_free_result($con);
mysqli_free_result($cb);
mysqli_free_result($bb);
mysqli_close($conexion);
?>