<?php
   /*  $cons_usuario="root";
    $cons_contra="";
    $cons_base_datos="autodb";
    $cons_equipo="localhost:3308"; */

    $conexion = mysqli_connect("localhost:3308","root","","autodb");
    
 /*    if(!$conexion)
    {
        echo "<h3>No se ha podido conectar PHP - MySQL, verifique sus datos.</h3><hr><br>";
    }
    else
    {
        echo "<h3>Conexion Exitosa PHP - MySQL</h3><hr><br>";
    } */