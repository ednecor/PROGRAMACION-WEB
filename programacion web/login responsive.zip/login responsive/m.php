<?php
include "final.php";
error_reporting(0);
session_start();


$varsesion = $_SESSION ['usuario'];
$var=$_SESSION['tiempo'];



if($varsesion==null || $varsesion = ''){
  echo '<script>
  alert("Por favor, inicie sesión para ingresar");
  window.location.href = "login.php";
    </script>';
    die();
}


$consulta="SELECT * from empresa";
$resultado=mysqli_query($conexion, $consulta);
$nombre=mysqli_fetch_array($resultado);


$rol=$_SESSION['rol'];
$con="select * from permiso where idpermiso in (select idpermiso from permisorol where idrol='1') order by cast(idpermiso as decimal);";
$resul=mysqli_query($conexion,$con);



 if (time() - $var >10000) {  
  echo '<script>
    alert("Ha estado inactivo");
    window.location.href="login.php";
      </script>';
    session_destroy();

  die();  
}
$_SESSION['tiempo']=time(); 
?>
<html>
   <head>
      <title>Menu</title>
      <link rel="stylesheet" href="es.css">
   </head>

   <body>

      <div id="header">
         <ul class="menu">
         <?php

while ($fila = mysqli_fetch_array($resul)){  ?>

<ul>

<li><a href=" <?php echo $fila['url'] ?> "> <?php echo $fila['nombre'] ?> </a></li>
<?php
$r=$fila['idpermiso'];
$n="SELECT * from permiso where fk_idpermiso='$r'";
$b=mysqli_query($conexion,$n);
       while ($submenu = mysqli_fetch_array($b)){ ?> 
<ul class="submenu">

<li><?php echo $submenu['nombre']; ?> </li>

</ul>
      <?php } ?>
</ul>

<?php }

?>
         </ul>
      </div>
   </body>
</html>