<?php
include "final.php";

session_start();

$usuario=$_POST['correo'];


$clave=$_POST['clave'];


$consulta="SELECT * from usuario WHERE email = '$usuario'  ";

$resultado=mysqli_query($conexion, $consulta);


$filas=mysqli_num_rows($resultado);

if  ($filas>0){
    $datos=mysqli_fetch_array($resultado);

    if (password_verify($clave, "$datos[contraseña]")){
        $_SESSION['usuario'] ="$datos[nombre] $datos[apellido]";
        $_SESSION['rol'] = "$datos[idrol]";
        $_SESSION['tiempo']=time();
        
        header("location:menuu.php");
        
        
        }else {
            
            echo '<script>
            alert(" clave invalido");
            window.history.go(-1);
            </script>';

        }

}else{
   
    echo '<script>
    alert("Correo invalido");
    window.history.go(-1);
    </script>';

    exit;

}

mysqli_free_result($resultado);
mysqli_close($conexion);