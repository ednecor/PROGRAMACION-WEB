<?php
include "final.php";
error_reporting(0);
session_start();


$varsesion = $_SESSION ['usuario'];
$var=$_SESSION['tiempo'];



if($varsesion==null || $varsesion = ''){
  echo '<script>
  alert("Por favor, inicie sesión para ingresar");
  window.location.href = "login.php";
    </script>';
    die();
}


$consulta="SELECT * from empresa";
$resultado=mysqli_query($conexion, $consulta);
$nombre=mysqli_fetch_array($resultado);


$rol=$_SESSION['rol'];
$con="select * from permiso where idpermiso in (select idpermiso from permisorol where idrol='1') order by cast(idpermiso as decimal);";
$resul=mysqli_query($conexion,$con);



 if (time() - $var >10000) {  
  echo '<script>
    alert("Ha estado inactivo");
    window.location.href="login.php";
      </script>';
    session_destroy();

  die();  
}
$_SESSION['tiempo']=time(); 
?>
<html>

<head>
    <title>Tutorial menu despegable</title>
    <style type="text/css">
        /* estilos universales */

        * {
            padding: 0px;
            margin: 0px;
        }

        /* contenedor header  */

        #header {
            margin: auto;
            width: 1000px;
            font-family: Arial, Helvetica, sans-serif;
        }

        /* reglas */

        ul, ol {
            list-style: none;
        }

        /* menu principal */

        .nav li a {
            background-color: #000;
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }

        /* cuando pase el cursor encima */

        .nav li a:hover {
            background-color: #434343;
        }

        /* li directos */

        .nav>li {
            float: left;
        }

        /* submenus */

        .nav li ul {
            display: none;
            position: absolute;
            min-width: 140px;
        }

        /* cuando pasemos el mouse y que aparezcan */

        .nav li:hover >ul {
            display: block;
        }

    </style>
</head>

<body>
    <div id="header">
        <ul class="nav">
             <?php
                while ($fila = mysqli_fetch_array($resul)){  ?>
                      
                         <li><a href=" <?php echo $fila['url'] ?> "> <?php echo $fila['nombre'] ?> </a>
                         <ul>
                         <?php
                                $r=$fila['idpermiso'];
                                $n="SELECT * from permiso where fk_idpermiso='$r'";
                                $b=mysqli_query($conexion,$n);
                                    while ($submenu = mysqli_fetch_array($b)){ ?> 
                                       <li><a href="logout.php"><?php echo $submenu['nombre'] ?></a></li>
                                    <?php } ?>
                        </ul> 
                        </li>
                      
               <?php }
                  ?>
            <!-- <li><a href="">Inicio</a></li>
            <li><a href="">Servicios</a>
                <ul>
                    <li><a href="">Submenu1</a></li>
                    <li><a href="">Submenu2</a></li>
                    <li><a href="">Submenu3</a></li>
                    <li><a href="">Submenu4</a>
                        <ul>
                            <li><a href="">Submenu1</a></li>
                            <li><a href="">Submenu2</a></li>
                            <li><a href="">Submenu3</a></li>
                            <li><a href="">Submenu4</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li><a href="">Acerca de</a>
                <ul>
                    <li><a href="">Submenu1</a></li>
                    <li><a href="">Submenu2</a></li>
                    <li><a href="">Submenu3</a></li>
                    <li><a href="">Submenu4</a></li>
                </ul>
            </li>
            <li><a href="">Contacto</a></li>  -->
        </ul>
    </div>
</body>

</html>