<?php
include "final.php";
error_reporting(0);
session_start();


$varsesion = $_SESSION ['usuario'];
$var=$_SESSION['tiempo'];



if($varsesion==null || $varsesion = ''){
  echo '<script>
  alert("Por favor, inicie sesión para ingresar");
  window.location.href = "login.php";
    </script>';
    die();
}


$consulta="SELECT * from empresa";
$resultado=mysqli_query($conexion, $consulta);
$nombre=mysqli_fetch_array($resultado);


$rol=$_SESSION['rol'];
$con="select * from permiso where idpermiso in (select idpermiso from permisorol where idrol='$rol') order by cast(idpermiso as decimal);";
$resul=mysqli_query($conexion,$con);



 if (time() - $var >10000) {  
  echo '<script>
    alert("Ha estado inactivo");
    window.location.href="login.php";
      </script>';
    session_destroy();

  die();  
}
$_SESSION['tiempo']=time(); 
?>

<DOCTYPE html>
    <html lang="es">

    <head>
        <title>Menu horizontal responsive</title>
        <meta chraset="UTF-8">
        <meta name="viewport"
            content="width=device-width, user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1">
        <link rel="stylesheet" href="est.css">
    </head>

    <body>
        <header>
            <input type="checkbox" id="btn-menu">
            <label for="btn-menu"><img src="imagen.png" alt=""></label>
            <nav class="menu">
                <ul>
                <li>
                 <p style="color:#ffffff; font-size:13pt; text-align:center; font-family:monospace">
               <?php 
                   $cons="SELECT rol.nombre from rol where idrol=$rol";
                   $res=mysqli_query($conexion, $cons);
                    $c=mysqli_fetch_array($res);
                     echo $c['nombre'];
               ?>
              </p>
            <p style="color:#ffffff; font-size:11pt; text-align:center; font-family:monospace">
                   Bienvenido, <?php echo $_SESSION['usuario']?>
            </p>
            <p style="color:#ffffff; font-size:7pt; text-align:center; font-family:monospace">
            <?php echo "$nombre[nombre]"?>
            </p>
         </li>
                <?php
                while ($fila = mysqli_fetch_array($resul)){  ?>
                <li><a href=" <?php echo $fila['url'] ?> "> <?php echo $fila['nombre'] ?> </a>
                <ul>
                         <?php
                                $r=$fila['idpermiso'];
                                $n="SELECT * from permiso where fk_idpermiso='$r'";
                                $b=mysqli_query($conexion,$n);
                                    while ($submenu = mysqli_fetch_array($b)){ ?> 
                                       <li><a href="logout.php"><?php echo $submenu['nombre'] ?></a></li>
                                    <?php } ?>
                        </ul> 
                </li>
                <?php }
                  ?>
                    <!-- <li><a href="">Inicio</a></li>
                    <li><a href="">Servicios</a></li>
                    <li><a href="">Productos</a></li>
                    <li><a href="">Clientes</a></li>
                    <li><a href="">Contacto</a></li> -->
                </ul>
            </nav>
        </header>

        <main>
            <h1>Menú horizontal responsive con css</h1>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Odio at quidem incidunt enim sunt quos officia natus ducimus facilis repudiandae molestias, nobis ea, modi explicabo reprehenderit exercitationem ad laborum tempora.</p>
            <p>Sit velit labore molestiae, earum sint deserunt harum sed libero, quae consequatur rerum dolore doloribus debitis autem illo? Labore tenetur porro, sit fugit alias amet! Odit sint cumque perspiciatis minima.</p>
            <p>Ex, culpa aut, temporibus commodi iste laborum minima corrupti voluptatibus molestiae laudantium autem facilis quas at aperiam reiciendis blanditiis quod iusto quibusdam consequuntur porro. Magni quis quam autem nihil odit?</p>
            <p>Eligendi laborum accusantium nihil corrupti? Distinctio eaque ut expedita quo dignissimos dolore fugiat alias molestiae quos. Sunt porro hic placeat earum animi soluta, sapiente a ipsam consectetur? Nobis, eius. Repellendus?</p>
        </main>
    </body>

    </html>