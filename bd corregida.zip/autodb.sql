-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3308
-- Tiempo de generación: 09-08-2020 a las 22:49:13
-- Versión del servidor: 8.0.18
-- Versión de PHP: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `autodb`
--
CREATE DATABASE IF NOT EXISTS `autodb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `autodb`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE IF NOT EXISTS `categoria` (
  `idcategoria` varchar(20) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idcategoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

DROP TABLE IF EXISTS `curso`;
CREATE TABLE IF NOT EXISTS `curso` (
  `idcurso` varchar(20) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `nit` varchar(20) DEFAULT NULL,
  `idcategoria` varchar(20) DEFAULT NULL,
  `idhorario` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idcurso`),
  KEY `fk_idcategoria` (`idcategoria`),
  KEY `fk_nit` (`nit`),
  KEY `fk_idhorario` (`idhorario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalleevaluacion`
--

DROP TABLE IF EXISTS `detalleevaluacion`;
CREATE TABLE IF NOT EXISTS `detalleevaluacion` (
  `numerodocumento` varchar(20) NOT NULL,
  `idevaluacion` varchar(20) NOT NULL,
  `nota` double DEFAULT NULL,
  PRIMARY KEY (`numerodocumento`,`idevaluacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

DROP TABLE IF EXISTS `documento`;
CREATE TABLE IF NOT EXISTS `documento` (
  `iddocumento` varchar(20) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `peso` int(11) DEFAULT NULL,
  `extension` varchar(10) DEFAULT NULL,
  `numerodocumento` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`iddocumento`),
  KEY `fk_numerodocumento` (`numerodocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empresa`
--

DROP TABLE IF EXISTS `empresa`;
CREATE TABLE IF NOT EXISTS `empresa` (
  `nit` varchar(20) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `direccion` varchar(20) DEFAULT NULL,
  `mision` varchar(500) DEFAULT NULL,
  `vision` varchar(500) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`nit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `empresa`
--

INSERT INTO `empresa` (`nit`, `nombre`, `direccion`, `mision`, `vision`, `telefono`) VALUES
('123456', 'Condu-florencia', 'calle 12 N 3 45', 'Orientar a la persona en su proceso de aprendizaje en la conduccion de vehiculos', 'Convertirnos en el principal centro de enseñanza de conduccion del Caqueta', '4347869');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `evaluacion`
--

DROP TABLE IF EXISTS `evaluacion`;
CREATE TABLE IF NOT EXISTS `evaluacion` (
  `idevaluacion` varchar(20) NOT NULL,
  `fecha` date DEFAULT NULL,
  PRIMARY KEY (`idevaluacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horario`
--

DROP TABLE IF EXISTS `horario`;
CREATE TABLE IF NOT EXISTS `horario` (
  `idhorario` varchar(20) NOT NULL,
  `dia` varchar(10) DEFAULT NULL,
  `horaentrada` varchar(10) DEFAULT NULL,
  `horasalidad` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idhorario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

DROP TABLE IF EXISTS `permiso`;
CREATE TABLE IF NOT EXISTS `permiso` (
  `idpermiso` varchar(10) NOT NULL,
  `nombre` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `url` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `fk_idpermiso` varchar(20) DEFAULT NULL,
  `estado` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`idpermiso`),
  KEY `fk_permiso` (`fk_idpermiso`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `permiso`
--

INSERT INTO `permiso` (`idpermiso`, `nombre`, `url`, `fk_idpermiso`, `estado`) VALUES
('1', 'Informacion personal', NULL, NULL, '1'),
('5', 'Informacion academica', NULL, NULL, '1'),
('6', 'Gestionar documentacion', NULL, NULL, '1'),
('9', 'Visualizar documentos', NULL, NULL, '1'),
('10', 'Visualizar informacion de cursos', NULL, NULL, '1'),
('13', 'Administrar cursos', NULL, NULL, '1'),
('14', 'Administrar tablas basicas', NULL, NULL, '1'),
('15', 'Cargar documentos financieros', 'subirdf.php', NULL, '1'),
('16', 'Administrar roles', NULL, NULL, '1'),
('17', 'Administrar usuarios', NULL, NULL, '1'),
('18', 'Ver informacion de aprendices', NULL, NULL, '1'),
('21', 'Cerrar sesion', 'logout.php', NULL, '1'),
('2', 'Gestionar contenido academico', NULL, NULL, '1'),
('3', 'Gestionar inscripciones', NULL, NULL, '1'),
('4', 'Actualizar informacion personal', 'actualizarpersonal.php', '1', '1'),
('8', 'Ver horarios', NULL, '5', '1'),
('7', 'Cargar documentos personales', 'subirdp.php', '1', '1'),
('11', 'Inscribir categoria', NULL, '5', '1'),
('12', 'Inscribir curso', NULL, '5', '1'),
('19', 'Ver promedios de aprendices', NULL, '18', '1'),
('20', 'Crear evaluaciones', NULL, '2', '1'),
('22', 'Inscribir aprendiz a curso', 'inscribiraprendizcurso.php', '3', '1'),
('23', 'Crear cursos', 'agregarcurso.php', '13', '1'),
('24', 'Eliminar cursos', 'eliminarcurso.php', '13', '1'),
('25', 'Definir horarios de cursos', 'definirhorario.php', '13', '1'),
('26', 'Visualizar totalidad de documentos', NULL, '6', '1'),
('27', 'Agregar tipo de documento identidad', 'agregartd.php', '14', '1'),
('28', 'Eliminar tipo de documentos identidad', 'eliminartid.php', '14', '1'),
('29', 'Agregar categoria licencia conduccion', 'agregarlc.php', '14', '1'),
('30', 'Eliminar categoria licencia conduccion', 'eliminarlc.php', '14', '1'),
('31', 'Eliminar horarios de cursos', 'eliminarhorario.php', '13', '1'),
('32', 'Buscar aprendiz', 'visualizarinfoaprendiz.php', '18', '1'),
('33', 'Cambiar rol de usuario', 'cambiarrolusuario.php', '17', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisorol`
--

DROP TABLE IF EXISTS `permisorol`;
CREATE TABLE IF NOT EXISTS `permisorol` (
  `idrol` varchar(20) NOT NULL,
  `idpermiso` varchar(20) NOT NULL,
  PRIMARY KEY (`idrol`,`idpermiso`),
  KEY `fk_idpermiso` (`idpermiso`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `permisorol`
--

INSERT INTO `permisorol` (`idrol`, `idpermiso`) VALUES
('1', '1'),
('1', '21'),
('1', '5'),
('2', '1'),
('2', '10'),
('2', '18'),
('2', '2'),
('2', '21'),
('3', '1'),
('3', '15'),
('3', '18'),
('3', '21'),
('3', '3'),
('4', '1'),
('4', '13'),
('4', '14'),
('4', '16'),
('4', '17'),
('4', '18'),
('4', '21'),
('4', '6'),
('4', '9');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pregunta`
--

DROP TABLE IF EXISTS `pregunta`;
CREATE TABLE IF NOT EXISTS `pregunta` (
  `idpregunta` varchar(20) NOT NULL,
  `descripcion` varchar(20) DEFAULT NULL,
  `idevaluacion` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idpregunta`),
  KEY `fk_idevaluacion` (`idevaluacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

DROP TABLE IF EXISTS `rol`;
CREATE TABLE IF NOT EXISTS `rol` (
  `idrol` varchar(10) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idrol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`idrol`, `nombre`) VALUES
('1', 'APRENDIZ'),
('2', 'INSTRUCTOR'),
('3', 'RECEPCIONISTA'),
('4', 'ADMINISTRADOR');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipodocumento`
--

DROP TABLE IF EXISTS `tipodocumento`;
CREATE TABLE IF NOT EXISTS `tipodocumento` (
  `idtipodocumento` varchar(20) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idtipodocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `tipodocumento`
--

INSERT INTO `tipodocumento` (`idtipodocumento`, `nombre`) VALUES
('1', 'Cedula de ciudadania'),
('2', 'Tarjeta de identidad'),
('3', 'Pasaporte');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE IF NOT EXISTS `usuario` (
  `numerodocumento` varchar(20) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `direccion` varchar(20) DEFAULT NULL,
  `telefono` varchar(10) DEFAULT NULL,
  `celular` varchar(10) DEFAULT NULL,
  `tiposangre` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `contraseña` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `idrol` varchar(10) DEFAULT NULL,
  `idtipodocumento` varchar(20) DEFAULT NULL,
  `idcurso` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`numerodocumento`),
  KEY `fk_idtipodocumento` (`idtipodocumento`),
  KEY `fk_idrol` (`idrol`),
  KEY `fk_idcurso` (`idcurso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`numerodocumento`, `nombre`, `apellido`, `direccion`, `telefono`, `celular`, `tiposangre`, `email`, `contraseña`, `idrol`, `idtipodocumento`, `idcurso`) VALUES
('1234', 'admin', 'istrador', NULL, '3125478987', NULL, NULL, 'admin@gmail.com', '$2y$10$PMvmrykHB1UGzip8uhxy1eeA/tcksQhEXrYs7ZkN06RtG9O/FTIYi', '4', NULL, NULL),
('3456', 'instru', 'ctor', NULL, '3502147752', NULL, NULL, 'instru@gmail.com', '$2y$10$0jH.DCxKWx54Q6ssTGL2aemuuWXteQEgW.TqmuvnNiVM/6Ukj8kaa', '2', NULL, NULL),
('4567', 'pedro', 'fes', '', '3112457326', '', '', 'aprendiz@gmail.com', '$2y$10$v3udOa/tjjvu5P.t2ynmJeOBf6C13GoXqwp9ci06mTTM5S6QblRei', '1', NULL, NULL),
('5554', 'javier', 'suarez', NULL, '3135998201', NULL, NULL, 'javisua@gmail.com', '$2y$10$sEBuP1Y/t2e4o/6LJuCrBe.FwWJx7h.9imFYz9EYofUsVfh4J5Spe', '1', NULL, NULL),
('8912', 'recep', 'cionista', NULL, '3009854211', NULL, NULL, 'recep@gmail.com', '$2y$10$WNswdAJ7AXR85A9A4aMbJuRTCd2fLOXaK8oDSgMuH1aArpAxdDgXK', '3', NULL, NULL);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `fk_idcategoria` FOREIGN KEY (`idcategoria`) REFERENCES `categoria` (`idcategoria`),
  ADD CONSTRAINT `fk_idhorario` FOREIGN KEY (`idhorario`) REFERENCES `horario` (`idhorario`),
  ADD CONSTRAINT `fk_nit` FOREIGN KEY (`nit`) REFERENCES `empresa` (`nit`);

--
-- Filtros para la tabla `documento`
--
ALTER TABLE `documento`
  ADD CONSTRAINT `fk_numerodocumento` FOREIGN KEY (`numerodocumento`) REFERENCES `usuario` (`numerodocumento`);

--
-- Filtros para la tabla `pregunta`
--
ALTER TABLE `pregunta`
  ADD CONSTRAINT `fk_idevaluacion` FOREIGN KEY (`idevaluacion`) REFERENCES `evaluacion` (`idevaluacion`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `fk_idcurso` FOREIGN KEY (`idcurso`) REFERENCES `curso` (`idcurso`),
  ADD CONSTRAINT `fk_idrol` FOREIGN KEY (`idrol`) REFERENCES `rol` (`idrol`),
  ADD CONSTRAINT `fk_idtipodocumento` FOREIGN KEY (`idtipodocumento`) REFERENCES `tipodocumento` (`idtipodocumento`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
